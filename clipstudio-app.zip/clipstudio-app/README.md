# ClipStudio Pro — installation en 3 étapes

## 1. Envoyer le projet sur GitHub (une seule fois)
Créez un compte gratuit sur github.com → **New repository** → **uploading an existing file** → glissez tout le contenu de ce dossier (y compris le dossier `.github`) → **Commit**.
La compilation démarre toute seule (onglet **Actions**, ~10 min).

## 2. Télécharger les applications
Onglet **Releases** (colonne de droite du dépôt) : 
- `ClipStudio-Pro-win.exe` → Windows (double-clic)
- `ClipStudio-Pro-mac.dmg` → Mac (glisser dans Applications)
- `ClipStudio-Pro-android.apk` → Android (ouvrir le fichier sur le téléphone, autoriser « sources inconnues »)

Lien fixe de la dernière version : `https://github.com/VOTRE-NOM/VOTRE-DEPOT/releases/latest`

## 3. Option « un simple lien » (sans fichier)
Dépôt → **Settings → Pages → Source : GitHub Actions**, puis relancez **Actions → Build apps → Run workflow**.
Vous obtenez une adresse web (`https://VOTRE-NOM.github.io/VOTRE-DEPOT/`). Ouvrez-la sur Android, Windows, Mac, iPhone, puis **Installer** : l'app s'ajoute comme une vraie application et fonctionne aussi hors ligne.

## À savoir
- Mac : premier lancement = clic droit > Ouvrir. Windows : SmartScreen > Informations complémentaires > Exécuter quand même.
- Le bouton « Enregistrer en MP4 » (ordinateur) convertit pour TikTok/Instagram.
- Compiler en local : `npm install`, `npm start` (test), `npm run dist:win` / `dist:mac`, `npm run android:init`. Play Store / App Store : signature et compte développeur requis.
