const { app, BrowserWindow, shell, session, ipcMain, dialog } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os'), { spawn } = require('child_process');
const ffmpeg = require('ffmpeg-static').replace('app.asar', 'app.asar.unpacked');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

function createWindow() {
  const w = new BrowserWindow({
    width: 1360, height: 860, minWidth: 420, minHeight: 600,
    backgroundColor: '#0e0f16', title: 'ClipStudio Pro',
    webPreferences: { contextIsolation: true, sandbox: true, backgroundThrottling: false, preload: path.join(__dirname, 'preload.js') }
  });
  w.removeMenu();
  w.loadFile(path.join(__dirname, 'www', 'index.html'));
  w.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
}

// Conversion WebM -> MP4 (H.264/AAC) accepté par TikTok, Instagram, etc.
ipcMain.handle('tomp4', async (e, ab) => {
  const tmp = path.join(os.tmpdir(), 'cs-' + Date.now()), inp = tmp + '.webm', out = tmp + '.mp4';
  fs.writeFileSync(inp, Buffer.from(ab));
  try {
    await new Promise((res, rej) => {
      const p = spawn(ffmpeg, ['-y', '-i', inp, '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-preset', 'fast', '-crf', '20', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', out]);
      p.on('error', rej); p.on('close', c => c ? rej(new Error('ffmpeg code ' + c)) : res());
    });
    const r = await dialog.showSaveDialog({ defaultPath: 'clip.mp4', filters: [{ name: 'MP4', extensions: ['mp4'] }] });
    if (!r.canceled) fs.copyFileSync(out, r.filePath);
    return !r.canceled;
  } finally { for (const f of [inp, out]) try { fs.unlinkSync(f); } catch (_) {} }
});

app.whenReady().then(() => {
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(['media', 'fullscreen'].includes(perm)));
  createWindow();
  app.on('activate', () => BrowserWindow.getAllWindows().length || createWindow());
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
