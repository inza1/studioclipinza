const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('desktop', { toMp4: ab => ipcRenderer.invoke('tomp4', ab) });
